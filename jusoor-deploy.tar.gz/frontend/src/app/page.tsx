import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { getPublishedNews, getPublishedVideos, getPublicAdPlacements, getPublicCrisisMode, getPublicSiteStructure, type PublicAdPlacement, type PublicHomepageSection } from "@/lib/news-api";
import type { StorySummary } from "@/lib/stories-api";
import { JsonLd } from "@/components/JsonLd";
import { buildOrganizationJsonLd } from "@/lib/seo";
import { absoluteUrl } from "@/lib/site";
import { StoryGridCard } from "@/components/StoryGridCard";
import { HomeHeroSlider } from "@/components/home/HomeHeroSlider";
import { ConfiguredAd } from "@/components/home/ConfiguredAd";
import { AdBox } from "@/components/home/AdBox";
import { ServicesBand } from "@/components/home/ServicesBand";
import { formatArabicDate } from "@/lib/format";
import { HomepagePollWidget } from "@/components/HomepagePollWidget";
import { AlertSubscriptionForm } from "@/components/AlertSubscriptionForm";

// The homepage is rendered per request so a newly published article (and a
// deleted one) is reflected immediately — no stale cache during the client trial.
export const dynamic = "force-dynamic";

export function generateMetadata(): Metadata {
  const canonical = absoluteUrl("/");
  return canonical ? { alternates: { canonical } } : {};
}

/**
 * Desk slug -> public label. The slugs are exactly the "presentation desks" an
 * editor ticks in the CMS (see EditorialDesk on the backend). A homepage section
 * shows ONLY published articles that carry that section's desk.
 */
const deskLabels: Record<string, string> = {
  mughtarib: "أخبار المغتربين", success: "قصص نجاح", egypt: "أخبار مصر", opportunities: "فرص استثمارية",
  official: "مع مسئول", events: "فعاليات", red: "خط أحمر", lamma: "اللمة الحلوة", secondgen: "الجيل الثاني",
  sports: "رياضة", arts: "فنون", articles: "مقالات رأي", fatwas: "الفتاوى",
};

function articleHref(story: StorySummary) {
  return story.slug ? `/article/${story.id}/${encodeURIComponent(story.slug)}` : `/article/${story.id}`;
}

function placeOf(story: StorySummary) {
  return story.cityNameAr ?? story.countryNameAr ?? "جسور";
}

/** Section heading, same markup as the Final Demo (`.section-head` + `.eyebrow` link). */
function Head({ label, slug, more, asHeading }: { label: string; slug: string; more?: string; asHeading?: boolean }) {
  const href = `/category?cat=${slug}`;
  const eyebrow = <Link className="eyebrow" href={href}>{label}</Link>;
  return (
    <div className="section-head">
      {asHeading ? <h2>{eyebrow}</h2> : eyebrow}
      {more && <Link className="more" href={href}>{more}</Link>}
    </div>
  );
}

function EmptyDesk({ label }: { label: string }) {
  return <div className="home-empty-desk"><span aria-hidden="true">✦</span><p>لا توجد مواد منشورة في «{label}» حتى الآن.</p><span>ستظهر التغطيات هنا بعد نشر خبر واختيار هذا القسم.</span></div>;
}

function HomeAdPlacement({ placement, className = "", ratio = "1 / 1", naturalSize = false }: { placement?: PublicAdPlacement; className?: string; ratio?: string; naturalSize?: boolean }) {
  if (!placement) return null;
  return <div className={`home-ad-placement ${className}`.trim()}><div className="wrap"><ConfiguredAd placement={placement} ratio={ratio} naturalSize={naturalSize} /></div></div>;
}

/** Demo's `.six-grid` of `.grid-card`s (cardGrid). */
function DeskGrid({ stories, label, columns, mobileVariant }: { stories: StorySummary[]; label: string; columns?: number; mobileVariant?: "lead" | "compact" }) {
  if (!stories.length) return <EmptyDesk label={label} />;
  return (
    <div className={`six-grid${mobileVariant ? ` home-news-grid home-news-grid--${mobileVariant}` : ""}`} style={columns ? { gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))` } : undefined}>
      {stories.map((story) => <StoryGridCard key={story.id} story={story} />)}
    </div>
  );
}

function EditorialColumn({ slug, stories }: { slug: "red" | "official"; stories: StorySummary[] }) {
  const title = deskLabels[slug];
  const href = `/category?cat=${slug}`;
  return (
    <section className={`editorial-column editorial-column--${slug}`} aria-label={title}>
      <div className="editorial-column__head">
        <Link href={href} className="editorial-column__title"><span aria-hidden="true" />{title}</Link>
        <Link href={href} className="editorial-column__more">{slug === "red" ? "كل التحديثات ←" : "كل اللقاءات ←"}</Link>
      </div>
      {stories.length ? <>
        <div className="editorial-top-grid">
          {stories.slice(0, 1).map((story) => (
            <Link key={story.id} href={articleHref(story)} className="editorial-top-card">
              <div className="editorial-top-card__image">
                {story.imageUrl ? <Image src={story.imageUrl} alt="" fill sizes="(max-width: 900px) 100vw, 35vw" unoptimized /> : <span>جسور</span>}
              </div>
              <h3>{story.title}</h3>
              <small className="editorial-top-card__meta">{placeOf(story)} · {formatArabicDate(story.publishedAtUtc)}</small>
            </Link>
          ))}
        </div>
        <div className="editorial-news-rows">
          {stories.slice(1, 4).map((story) => (
            <Link key={story.id} href={articleHref(story)} className="editorial-news-row">
              {story.imageUrl ? <Image src={story.imageUrl} alt="" width={224} height={156} unoptimized /> : <span className="editorial-news-row__ph" aria-hidden="true">جسور</span>}
              <span className="editorial-news-row__body">
                <h3>{story.title}</h3>
                <small>{placeOf(story)} · {formatArabicDate(story.publishedAtUtc)}</small>
              </span>
            </Link>
          ))}
        </div>
      </> : <EmptyDesk label={title} />}
    </section>
  );
}

/** Demo's cardLamma(): `.lamma-card` > `.thumb` + h4 + `.foot`. */
function LammaCard({ story }: { story: StorySummary }) {
  return (
    <Link className="lamma-card" href={articleHref(story)} aria-label={story.title}>
      <div className={`thumb${story.imageUrl ? "" : " thumb-placeholder"}`}>
        {story.imageUrl ? <Image src={story.imageUrl} alt="" width={720} height={480} unoptimized /> : <span>ج</span>}
      </div>
      <h4>{story.title}</h4>
      <div className="foot"><span>{placeOf(story)}</span><span>·</span><span>{formatArabicDate(story.publishedAtUtc)}</span></div>
    </Link>
  );
}

/**
 * Lamma + events. On web the wide "lamma-top" ad heads the Lamma column (level with the
 * events heading) and the square "lamma-events-square" ad sits under the events widget.
 * Both columns end on the same line: the wide ad takes the height the Lamma column has
 * to spare, so Lamma's last cards line up with the bottom of the square ad.
 */
function LammaSection({ lamma, events, topAd, sideAd }: { lamma: StorySummary[]; events: StorySummary[]; topAd?: PublicAdPlacement; sideAd?: PublicAdPlacement }) {
  const [feature, ...rest] = lamma;
  return (
    <section className="section tight on-surface" id="lamma">
      <div className="wrap">
        <div className="split-2 lamma-split" style={{ gridTemplateColumns: "1fr 340px" }}>
          <div className="lamma-main">
            <AdBox placement={topAd} ratio="3 / 1" fill className="lamma-top-ad ad-box--web-only" />
            <Head label={deskLabels.lamma} slug="lamma" more="كل اللمّات ←" />
            {feature ? <>
              <Link className="lead-story lamma-feature" href={articleHref(feature)}>
                <div className="lead-story-img">
                  {feature.imageUrl ? <Image src={feature.imageUrl} alt="" width={1200} height={760} unoptimized /> : <div className="home-hero-fallback" aria-hidden="true"><span>جسور</span></div>}
                  <span className="lamma-badge">🤝 لمّة الجالية</span>
                </div>
                <div className="lead-story-body">
                  <h2>{feature.title}</h2>
                  {feature.excerpt && <p className="sub">{feature.excerpt}</p>}
                  <div className="foot"><span>{placeOf(feature)}</span><span>·</span><span>{formatArabicDate(feature.publishedAtUtc)}</span></div>
                </div>
              </Link>
              {rest.length > 0 && <div className="lamma-grid">{rest.slice(0, 2).map((story) => <LammaCard key={story.id} story={story} />)}</div>}
            </> : <EmptyDesk label={deskLabels.lamma} />}
          </div>
          <aside className="lamma-side">
            <div className="lamma-side__events">
              <div className="section-head"><h2 style={{ fontSize: 14 }}>📅 فعاليات وتغطيات</h2></div>
              <div className="events-widget">
                {events.slice(0, 4).map((story) => (
                  <Link className="event-item" key={story.id} href={articleHref(story)}>
                    <span className="event-date"><b>{story.publishedAtUtc ? new Date(story.publishedAtUtc).getDate() : "—"}</b><span>{story.publishedAtUtc ? new Date(story.publishedAtUtc).toLocaleDateString("ar-EG", { month: "short" }) : ""}</span></span>
                    <span><h5>{story.title}</h5><span className="foot">{placeOf(story)} · {formatArabicDate(story.publishedAtUtc)}</span></span>
                  </Link>
                ))}
                {events.length === 0 && <EmptyDesk label={deskLabels.events} />}
                <Link href="/category?cat=events" className="cta">شاهد كل الفعاليات ←</Link>
              </div>
            </div>
            <AdBox placement={sideAd} ratio="1 / 1" fill className="lamma-side-ad ad-box--web-only" />
          </aside>
        </div>
      </div>
    </section>
  );
}

function AtmaenFeature({ webAd, mobileAd }: { webAd?: PublicAdPlacement; mobileAd?: PublicAdPlacement }) {
  return (
    <section className="section atmaen-feature-section" id="atmaen"><div className="wrap"><div className="atmaen-feature-card"><div className="split-2 atmaen-feature-layout">
          <div><span className="eyebrow atmaen-feature-eyebrow">على منصة جسور فقط</span><h2 className="atmaen-feature-title">لا تنتظر أخبار الوكالات والمراسلين وقت الأزمات الكبرى.. تابع المستجدات المعتمدة، وأرسل بلاغًا خاصًا للاطمئنان على مغتربك</h2>
          <div className="flex gap-8 mt-24 atmaen-feature-actions"><Link className="btn btn-primary" href="/atmaen">اطمّن على مغتربك</Link><Link className="btn btn-ghost" href="/crisis">مركز الأزمة</Link></div>
        </div>
        <ConfiguredAd placement={webAd} className="atmaen-ad-slot atmaen-ad-slot--web" ratio="1424 / 745" />
        <ConfiguredAd placement={mobileAd} className="atmaen-ad-slot atmaen-ad-slot--mobile" ratio="1424 / 745" />
      </div></div></div></section>
  );
}

function NewsRecirculation({ desks }: { desks: Record<string, StorySummary[]> }) {
  const sections = [{ slug: "arts", variant: "lead" }, { slug: "sports", variant: "compact" }, { slug: "fatwas", variant: "lead" }] as const;
  return (
    <section className="section tight recirc-section"><div className="wrap"><div className="recirc-cols">{sections.map(({ slug, variant }) => {
      const label = deskLabels[slug];
      const [lead, ...rest] = desks[slug] ?? [];
      return <div className={`recirc-col home-news-grid home-news-grid--${variant}`} key={slug}><Link href={`/category?cat=${slug}`} className="eyebrow">{label}</Link>
        {lead ? <><Link className="recirc-feature" href={articleHref(lead)}><div className="thumb">{lead.imageUrl ? <Image src={lead.imageUrl} alt="" width={720} height={440} unoptimized /> : <span>جسور</span>}</div><h4>{lead.title}</h4><div className="foot">{placeOf(lead)} · {formatArabicDate(lead.publishedAtUtc)}</div></Link>
          <div className="articles-list">{rest.slice(0, 3).map((story) => <Link className="row-card" href={articleHref(story)} key={story.id}><div className="thumb">{story.imageUrl && <Image src={story.imageUrl} alt="" width={200} height={140} unoptimized />}</div><div><h4>{story.title}</h4><div className="foot">{placeOf(story)} · {formatArabicDate(story.publishedAtUtc)}</div></div></Link>)}</div></>
        : <EmptyDesk label={label} />}
      </div>;
    })}</div></div></section>
  );
}

function ConfiguredHomepageSections({ sections, desks }: { sections: PublicHomepageSection[]; desks: Record<string, StorySummary[]> }) {
  return <>{sections.filter((section) => section.isEnabled && (section.showOnWeb || section.showOnMobile)).sort((a, b) => a.displayOrder - b.displayOrder).map((section) => {
    const stories = desks[section.deskSlug] ?? [];
    const className = `section tight home-config-section${section.showOnWeb && !section.showOnMobile ? " home-config-section--web" : ""}${!section.showOnWeb && section.showOnMobile ? " home-config-section--mobile" : ""}`;
    const columns = section.layout === "columns" ? 2 : section.layout === "lead" ? 2 : 3;
    return <section className={className} id={`home-${section.key}`} key={section.key}><div className="wrap">
      <Head label={section.title} slug={section.deskSlug} more={`كل ${section.title} ←`} />
      <DeskGrid stories={stories.slice(0, 6)} label={section.title} columns={columns} mobileVariant={section.layout === "lead" ? "lead" : "compact"} />
    </div></section>;
  })}</>;
}

export default async function HomePage() {
  const deskSlugs = Object.keys(deskLabels);
  const [[newsResult, videoResult, webAdsResult, mobileAdsResult, crisisResult, structureResult], deskResults] = await Promise.all([
    Promise.allSettled([
      getPublishedNews(1, 50),
      getPublishedVideos(1, 7, true), // Only the editor-curated seven videos belong in the hero.
      getPublicAdPlacements("web"),
      getPublicAdPlacements("mobile"),
      getPublicCrisisMode(),
      getPublicSiteStructure(),
    ] as const),
    Promise.allSettled(deskSlugs.map((slug) => getPublishedNews(1, 10, slug))),
  ]);
  const feed = newsResult.status === "fulfilled" ? newsResult.value.items : [];
  const videos = videoResult.status === "fulfilled" ? videoResult.value.items : [];
  const webAds = webAdsResult.status === "fulfilled" ? webAdsResult.value : [];
  const mobileAds = mobileAdsResult.status === "fulfilled" ? mobileAdsResult.value : [];
  const crisis = crisisResult.status === "fulfilled" && crisisResult.value.isActive ? crisisResult.value : null;
  const homepageSections = structureResult.status === "fulfilled" ? structureResult.value.homepageSections : [];
  const ad = (surface: "web" | "mobile", slotKey: string) =>
    (surface === "web" ? webAds : mobileAds).find((placement) => placement.slotKey === slotKey);
  const desks: Record<string, StorySummary[]> = Object.fromEntries(deskSlugs.map((slug, index) => {
    const result = deskResults[index];
    return [slug, result?.status === "fulfilled" ? result.value.items : []];
  }));

  // Only videos explicitly selected on their articles are returned by the videos API.
  const heroSlides = videos.map((video) => ({
    id: video.id, title: video.title, excerpt: video.excerpt, href: `/article/${video.id}/${encodeURIComponent(video.slug)}`,
    imageUrl: video.thumbnailUrl, videoUrl: video.videoUrl, isEmbedded: video.isEmbedded, publishedAtUtc: video.publishedAtUtc,
  }));

  const latest = feed.slice(0, 6);

  // Section order and markup mirror the approved Final Demo's home page. The demo's
  // video rail, "خط أحمر" band, UAE strip and sports band are hidden/commented out
  // there, so they are intentionally not rendered here either.
  return (
    <main id="main">
      <JsonLd data={buildOrganizationJsonLd()} />
      {crisis && <section className="wrap" aria-label="تنبيه أزمة نشطة"><Link className="crisis-spotlight" href="/crisis"><span className="crisis-spotlight__eyebrow"><i className="crisis-bar__dot" aria-hidden="true" />مركز الأزمة · {crisis.severity === "emergency" ? "طوارئ" : crisis.severity === "advisory" ? "تنبيه" : "عاجل"}</span><h2 className="crisis-spotlight__title">{crisis.title}</h2><p className="crisis-spotlight__summary">{crisis.summary}</p><span className="crisis-spotlight__actions"><span className="primary">التفاصيل وإرشادات المتابعة ←</span></span></Link></section>}
      {heroSlides.length > 0 && <HomeHeroSlider slides={heroSlides} />}
      <HomeAdPlacement placement={ad("mobile", "hero-after-videos")} className="home-ad-placement--mobile-only home-ad-placement--mobile-after-videos" />

      <section className="section tight on-surface">
        <div className="wrap">
          <Head label={deskLabels.mughtarib} slug="mughtarib" />
          <DeskGrid stories={desks.mughtarib.slice(0, 6)} label={deskLabels.mughtarib} mobileVariant="lead" />
        </div>
      </section>
      <HomeAdPlacement placement={ad("mobile", "after-mughtarib")} className="home-ad-placement--mobile-only" />
      <ServicesBand ad={ad("web", "services-inline")} />
      <AtmaenFeature webAd={ad("web", "atmaen-ad")} mobileAd={ad("mobile", "atmaen-ad")} />

      {/* الويب يحتفظ بمساحة الإعلان الجانبية؛ إعلانات الموبايل تظهر بعد السكشن. */}
      <section className="section on-surface">
        <div className="wrap">
          <div className="split-2">
            <aside className="sidebar-interactive-ad home-success-aside">
              <ConfiguredAd placement={ad("web", "success-ad")} className="home-success-desktop-ad" />
              <ConfiguredAd placement={ad("mobile", "success-ad")} className="home-success-mobile-ad" />
            </aside>
            <div className="home-success-stories">
              <Head label={deskLabels.success} slug="success" asHeading />
              <DeskGrid stories={desks.success.slice(0, 4)} label={deskLabels.success} columns={2} />
            </div>
          </div>
        </div>
      </section>
      <section className="section tight on-surface">
        <div className="wrap">
          <Head label={deskLabels.egypt} slug="egypt" />
          <DeskGrid stories={desks.egypt.slice(0, 6)} label={deskLabels.egypt} mobileVariant="compact" />
        </div>
      </section>

      <HomeAdPlacement placement={ad("web", "editorial-top")} className="home-wide-ad home-wide-ad--web-only home-ad-placement--natural" naturalSize />
      <section className="section editorial-columns-section" aria-label="خط أحمر ومع مسؤول">
        <div className="wrap">
          <div className="editorial-columns">
            <EditorialColumn slug="red" stories={desks.red.slice(0, 4)} />
            <EditorialColumn slug="official" stories={desks.official.slice(0, 4)} />
          </div>
        </div>
      </section>

      <section className="on-ink section tight opinion-section" id="opinion">
        <div className="wrap">
          <Head label={deskLabels.articles} slug="articles" more="كل المقالات ←" />
          {desks.articles.length ? (
            <div className="opinion-grid">
              {desks.articles.slice(0, 8).map((story, index) => (
                <article className={`opinion-tile${index === 0 ? " featured" : ""}`} key={story.id}>
                  <div className="opinion-tile-title"><Link href={articleHref(story)}>{story.title}</Link></div>
                  {story.authorName && <div className="opinion-byline" aria-label={`بقلم ${story.authorName}`}>
                    {story.authorImageUrl
                      ? <Image className="opinion-avatar" src={story.authorImageUrl} alt={story.authorName} width={70} height={70} unoptimized />
                      : <span className="opinion-avatar opinion-avatar--initials" aria-hidden="true">{story.authorName.trim().slice(0, 1)}</span>}
                    <span>{story.authorName}</span>
                  </div>}
                </article>
              ))}
            </div>
          ) : <EmptyDesk label={deskLabels.articles} />}
        </div>
      </section>

      <section className="section on-surface opportunities-section">
        <div className="wrap">
          <div className="split-2">
            <div>
              <Head label={deskLabels.opportunities} slug="opportunities" />
              <DeskGrid stories={desks.opportunities.slice(0, 4)} label={deskLabels.opportunities} columns={2} />
            </div>
            <div className="latest-news-column">
              <aside>
                <div className="section-head"><h2><span className="eyebrow">أحدث الأخبار</span></h2></div>
                <div className="rank-list">
                  {latest.slice(0, 6).map((story, index) => (
                    <Link className={`item home-rank-item${index < 3 ? " top" : ""}`} href={articleHref(story)} key={story.id}>
                      <span className="rank">{String(index + 1).padStart(2, "0")}</span>
                      <div><h5>{story.title}</h5></div>
                    </Link>
                  ))}
                </div>
              </aside>
              {/* Its own box (not inside the latest-news frame), with its own entrance animation. */}
              <AdBox placement={ad("web", "latest-news-square")} ratio="1 / 1" className="latest-news-ad ad-box--web-only" />
            </div>
          </div>
        </div>
      </section>

      <section className="section" id="second-gen">
        <div className="wrap">
          <Head label={deskLabels.secondgen} slug="secondgen" asHeading />
          <DeskGrid stories={desks.secondgen.slice(0, 4)} label={deskLabels.secondgen} columns={4} />
        </div>
      </section>

      <LammaSection lamma={desks.lamma} events={desks.events} topAd={ad("web", "lamma-top")} sideAd={ad("web", "lamma-events-square")} />

      <ConfiguredHomepageSections sections={homepageSections} desks={desks} />

      <section className="section on-surface" id="city-alerts" style={{ paddingTop: 0 }}>
        <div className="wrap">
          <div className="cta-banner">
            <div><h2>ما تفوّتش أي تحديث يخص بلدك</h2><p>اشترك في تنبيهات المدينة اللي إنت أو أهلك فيها — إشعار لحظي وقت الأزمات فقط، مفيش إزعاج يومي.</p></div>
            <AlertSubscriptionForm />
          </div>
        </div>
      </section>

      <NewsRecirculation desks={desks} />
      <HomepagePollWidget />
    </main>
  );
}
